#ifndef OPENGL_H
#define OPENGL_H

void initGLUT(int argc, char **argv);

#endif		/* OPENGL_H */